# app.py
import os
import json
import requests
from flask import Flask, request, session, redirect, url_for, jsonify, render_template_string
from dotenv import load_dotenv

load_dotenv()

# --- CONFIG ---
with open("config.json") as f:
    CONFIG = json.load(f)

PANEL_URL = CONFIG["PTERODACTYL_URL"].rstrip("/")
API_KEY = CONFIG["API_KEY"]
DEFAULT_LOCATION_ID = CONFIG["DEFAULT_LOCATION_ID"]
DEFAULT_NODE_ID = CONFIG["DEFAULT_NODE_ID"]
ADMIN_DISCORD_IDS = set(str(x) for x in CONFIG.get("admin_discord_ids", []))

DISCORD_CLIENT_ID = os.getenv("DISCORD_CLIENT_ID")
DISCORD_CLIENT_SECRET = os.getenv("DISCORD_CLIENT_SECRET")
REDIRECT_URI = "http://localhost:3007/auth/discord/callback"

HEADERS_APP = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json",
    "Accept": "Application/vnd.pterodactyl.v1+json"
}

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", os.urandom(24))

COINS_FILE = "coins.json"
if not os.path.exists(COINS_FILE):
    with open(COINS_FILE, "w") as f:
        json.dump({}, f)

# --- Coin System ---
def load_coins():
    with open(COINS_FILE, "r") as f:
        return json.load(f)

def save_coins(coins):
    with open(COINS_FILE, "w") as f:
        json.dump(coins, f, indent=2)

def add_coins(email, amount):
    coins = load_coins()
    coins[email] = coins.get(email, 0) + amount
    save_coins(coins)

# --- Auth Decorators ---
def admin_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("is_admin"):
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function

def user_login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_email' not in session and not session.get("is_admin"):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# --- Discord OAuth Routes ---
@app.route('/admin/login')
def admin_login():
    return render_template_string(ADMIN_LOGIN_HTML)

@app.route('/auth/discord')
def discord_login():
    return redirect(
        f"https://discord.com/api/oauth2/authorize?client_id={DISCORD_CLIENT_ID}"
        f"&redirect_uri={REDIRECT_URI}&response_type=code&scope=identify"
    )

@app.route('/auth/discord/callback')
def discord_callback():
    code = request.args.get("code")
    if not code:
        return "❌ No code received", 400

    # Exchange code for token
    data = {
        "client_id": DISCORD_CLIENT_ID,
        "client_secret": DISCORD_CLIENT_SECRET,
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": REDIRECT_URI,
        "scope": "identify"
    }
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    r = requests.post("https://discord.com/api/oauth2/token", data=data, headers=headers)
    if r.status_code != 200:
        return "❌ Failed to get token", 400

    token = r.json()["access_token"]
    user = requests.get("https://discord.com/api/users/@me", headers={"Authorization": f"Bearer {token}"}).json()
    discord_id = str(user["id"])

    if discord_id in ADMIN_DISCORD_IDS:
        session["is_admin"] = True
        session["discord_id"] = discord_id
        session["discord_username"] = f"{user['username']}#{user['discriminator']}"
        return redirect(url_for('admin_panel'))
    else:
        return "❌ You are not an admin.", 403

# --- User Login (Pterodactyl) ---
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        try:
            r = requests.post(f"{PANEL_URL}/api/client/auth/login", json={"email": email, "password": password})
            if r.status_code == 200:
                session['user_email'] = email
                return redirect(url_for('dashboard'))
        except:
            pass
        return "Login failed", 401
    return render_template_string(LOGIN_HTML)

# --- Routes ---
@app.route('/')
def index():
    if session.get("is_admin"):
        return redirect(url_for('admin_panel'))
    elif 'user_email' in session:
        return redirect(url_for('dashboard'))
    else:
        return redirect(url_for('login'))

@app.route('/dashboard')
@user_login_required
def dashboard():
    email = session.get("user_email")
    balance = load_coins().get(email, 0)
    return render_template_string(DASHBOARD_HTML, balance=balance, email=email)

@app.route('/admin')
@admin_required
def admin_panel():
    coins = load_coins()
    users = requests.get(f"{PANEL_URL}/api/application/users?per_page=1000", headers=HEADERS_APP).json()
    servers = requests.get(f"{PANEL_URL}/api/application/servers?per_page=1000", headers=HEADERS_APP).json()
    return render_template_string(ADMIN_PANEL_HTML, 
        discord_user=session["discord_username"],
        total_users=users["meta"]["pagination"]["total"],
        total_servers=servers["meta"]["pagination"]["total"],
        coins=coins
    )

@app.route('/admin/add_coins', methods=['POST'])
@admin_required
def admin_add_coins():
    email = request.form.get("email")
    amount = int(request.form.get("amount", 0))
    if email and amount > 0:
        add_coins(email, amount)
        return jsonify({"success": True, "message": f"Added {amount} coins to {email}"})
    return jsonify({"success": False})

@app.route('/admin/create_user', methods=['POST'])
@admin_required
def admin_create_user():
    email = request.form.get("email")
    data = {
        "username": email.split("@")[0],
        "email": email,
        "first_name": "User",
        "last_name": "",
        "password": "Auto@12345",
        "root_admin": False
    }
    r = requests.post(f"{PANEL_URL}/api/application/users", headers=HEADERS_APP, json=data)
    if r.status_code in [200, 201]:
        return jsonify({"success": True, "message": f"User {email} created"})
    return jsonify({"success": False, "message": "Failed"})

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# --- TEMPLATES ---
LOGIN_HTML = '''<h2>User Login</h2><form method="POST">Email: <input name="email" required><br>Password: <input name="password" type="password" required><br><button>Login</button></form><br><a href="/admin/login">Admin Login</a>'''
ADMIN_LOGIN_HTML = '''<h2>🔐 Admin Login</h2><a href="/auth/discord"><button class="btn btn-primary">Login with Discord</button></a>'''
DASHBOARD_HTML = '''<h2>User Dashboard</h2><p>Email: {{ email }} | Balance: {{ balance }} coins</p><a href="/logout">Logout</a>'''
ADMIN_PANEL_HTML = '''
<!DOCTYPE html>
<html>
<head><title>Admin Panel</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-4">
<h2>👑 Admin Panel</h2>
<p>Logged in as: <b>{{ discord_user }}</b> <a href="/logout" class="btn btn-outline-danger btn-sm">Logout</a></p>

<div class="row">
  <div class="col-md-4"><div class="card"><div class="card-body"><h5>Total Users</h5><h2>{{ total_users }}</h2></div></div></div>
  <div class="col-md-4"><div class="card"><div class="card-body"><h5>Total Servers</h5><h2>{{ total_servers }}</h2></div></div></div>
</div>

<h3 class="mt-4">💰 Add Coins</h3>
<form id="coinForm">
  <div class="mb-2"><input type="email" id="email" class="form-control" placeholder="User Email" required></div>
  <div class="mb-2"><input type="number" id="amount" class="form-control" placeholder="Coins" required></div>
  <button type="submit" class="btn btn-success">Add Coins</button>
</form>
<div id="coinResult" class="mt-2"></div>

<h3 class="mt-4">➕ Create User</h3>
<form id="userForm">
  <div class="mb-2"><input type="email" id="userEmail" class="form-control" placeholder="Email" required></div>
  <button type="submit" class="btn btn-primary">Create User</button>
</form>
<div id="userResult" class="mt-2"></div>

<h3 class="mt-4">📊 Coin Balances</h3>
<table class="table table-sm">
  <thead><tr><th>Email</th><th>Coins</th></tr></thead>
  <tbody>
    {% for email, balance in coins.items() %}
    <tr><td>{{ email }}</td><td>{{ balance }}</td></tr>
    {% endfor %}
  </tbody>
</table>

<script>
async function submitForm(url, inputs, resultId) {
  const data = {};
  inputs.forEach(id => data[id] = document.getElementById(id).value);
  const res = await fetch(url, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(data)});
  const r = await res.json();
  document.getElementById(resultId).className = r.success ? 'alert alert-success' : 'alert alert-danger';
  document.getElementById(resultId).textContent = r.message || (r.success ? 'Success' : 'Failed');
}

document.getElementById('coinForm').onsubmit = e => { e.preventDefault(); submitForm('/admin/add_coins', ['email', 'amount'], 'coinResult'); };
document.getElementById('userForm').onsubmit = e => { e.preventDefault(); submitForm('/admin/create_user', ['userEmail'], 'userResult'); };
</script>
</body>
</html>
'''

if __name__ == '__main__':
    print("✅ Starting Dashboard on http://localhost:3007")
    print("🔐 Admin login: http://localhost:3007/admin/login")
    app.run(host="127.0.0.1", port=3007, debug=True)